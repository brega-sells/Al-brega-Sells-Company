// الصق هنا إعدادات مشروع Firebase الخاص بك (من: Project settings → Your apps → SDK setup and configuration)
// استبدل القيم بين علامات التنصيص فقط، ولا تغيّر أسماء الحقول.
window.FIREBASE_CONFIG = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "000000000000",
  appId: "1:000000000000:web:0000000000000000"
};
