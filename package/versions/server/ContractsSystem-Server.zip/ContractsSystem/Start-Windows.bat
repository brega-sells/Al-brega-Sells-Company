@echo off
chcp 65001 >nul
title Contracts System
cd /d "%~dp0"
where python >nul 2>nul
if %errorlevel%==0 (
  python server.py %*
) else (
  py -3 server.py %*
)
echo.
echo The server stopped. Press any key to close.
pause >nul
