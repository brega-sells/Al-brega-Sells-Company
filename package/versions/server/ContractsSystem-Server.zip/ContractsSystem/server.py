# -*- coding: utf-8 -*-
"""
منظومة العقود والاحتياجات — خادم داخلي
وزارة الصناعة والمعادن · شركة البريقة لتسويق النفط

يعمل بـ Python 3.8+ فقط، بدون أي مكتبات إضافية.
التشغيل:  python server.py            (المنفذ الافتراضي 8080)
          python server.py --port 80
"""
import argparse, base64, datetime, hashlib, hmac, io, json, os, re, secrets, shutil, sqlite3, sys, threading, time, zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http import cookies
from urllib.parse import urlparse, parse_qs, unquote
from xml.sax.saxutils import escape as xesc
import xml.etree.ElementTree as ET

BASE = os.path.dirname(os.path.abspath(__file__))
STATIC = os.path.join(BASE, 'static')
DATA = os.path.join(BASE, 'data')
FILES = os.path.join(DATA, 'files')
BACKUPS = os.path.join(DATA, 'backups')
DBPATH = os.path.join(DATA, 'system.db')
SEED = os.path.join(BASE, 'seed', 'initial-data.json')
COLLECTIONS = {'contracts', 'needs', 'batches', 'extensions', 'letters', 'companies', 'config'}
ROLES = {'admin': 'مدير النظام', 'editor': 'محرر', 'viewer': 'مشاهد'}
SESSION_HOURS = 12
MAX_UPLOAD = 25 * 1024 * 1024
LOCK = threading.Lock()

def now_iso():
    return datetime.datetime.now().isoformat(timespec='seconds')

def conn():
    c = sqlite3.connect(DBPATH, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA journal_mode=WAL')
    return c

def hash_pw(pw, salt=None):
    salt = salt or secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac('sha256', pw.encode('utf-8'), bytes.fromhex(salt), 200000).hex()
    return h, salt

def init_db():
    os.makedirs(FILES, exist_ok=True); os.makedirs(BACKUPS, exist_ok=True)
    c = conn()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS docs(col TEXT, id TEXT, data TEXT, ver INTEGER, deleted INTEGER DEFAULT 0,
        updated_at TEXT, updated_by TEXT, PRIMARY KEY(col,id));
    CREATE INDEX IF NOT EXISTS docs_ver ON docs(ver);
    CREATE TABLE IF NOT EXISTS users(username TEXT PRIMARY KEY, name TEXT, role TEXT, pw_hash TEXT, salt TEXT,
        created_at TEXT, last_login TEXT);
    CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, username TEXT, expires REAL);
    CREATE TABLE IF NOT EXISTS log(ts TEXT, username TEXT, action TEXT, col TEXT, doc_id TEXT, summary TEXT);
    CREATE TABLE IF NOT EXISTS files(id TEXT PRIMARY KEY, name TEXT, mime TEXT, size INTEGER, uploaded_by TEXT, ts TEXT);
    ''')
    if c.execute('SELECT COUNT(*) FROM users').fetchone()[0] == 0:
        pw = secrets.token_urlsafe(9)
        h, s = hash_pw(pw)
        c.execute('INSERT INTO users VALUES(?,?,?,?,?,?,NULL)', ('admin', 'مدير النظام', 'admin', h, s, now_iso()))
        with open(os.path.join(DATA, 'كلمة-مرور-المدير-الأولية.txt'), 'w', encoding='utf-8') as f:
            f.write('اسم المستخدم: admin\nكلمة المرور: %s\n\nغيّرها بعد أول دخول من صفحة «الإعدادات»، ثم احذف هذا الملف.\n' % pw)
        print('\n  تم إنشاء حساب المدير:  admin  /  %s' % pw)
        print('  (محفوظة أيضًا في data/كلمة-مرور-المدير-الأولية.txt)\n')
    if c.execute('SELECT COUNT(*) FROM docs').fetchone()[0] == 0 and os.path.exists(SEED):
        seed = json.load(open(SEED, encoding='utf-8'))
        ver = 0; ts = now_iso()
        for col in ('batches', 'contracts', 'needs', 'extensions', 'letters', 'companies'):
            for o in seed.get(col, []):
                ver += 1; o = dict(o); oid = o.pop('id')
                c.execute('INSERT INTO docs VALUES(?,?,?,?,0,?,?)', (col, oid, json.dumps(o, ensure_ascii=False), ver, ts, 'استيراد أولي'))
        c.execute('INSERT INTO log VALUES(?,?,?,?,?,?)', (ts, 'system', 'استيراد', '', '', 'تحميل البيانات الأولية: %d سجل' % ver))
        print('  تم تحميل البيانات الأولية: %d سجل' % ver)
    c.commit(); c.close()

def daily_backup():
    """نسخة احتياطية يومية من قاعدة البيانات، يُحتفظ بآخر 30 نسخة."""
    while True:
        try:
            name = os.path.join(BACKUPS, 'system-%s.db' % datetime.date.today().isoformat())
            if not os.path.exists(name):
                src = conn(); dst = sqlite3.connect(name); src.backup(dst); dst.close(); src.close()
                olds = sorted(f for f in os.listdir(BACKUPS) if f.endswith('.db'))
                for f in olds[:-30]: os.remove(os.path.join(BACKUPS, f))
        except Exception as e:
            print('backup error:', e)
        time.sleep(3600)

def summarize(col, data):
    if not data: return ''
    if col == 'contracts': return '%s — %s' % (data.get('no', ''), data.get('company', ''))
    if col == 'needs': return data.get('company', '')
    if col == 'batches': return data.get('name', '')
    if col in ('extensions', 'letters'): return 'عقد %s' % data.get('contractNo', '')
    if col == 'config': return 'الإعدادات'
    return data.get('name', '') or ''

# ---------------- XLSX (بدون مكتبات) ----------------
def col_letter(i):
    s = ''
    i += 1
    while i: i, r = divmod(i - 1, 26); s = chr(65 + r) + s
    return s

def build_xlsx(sheets):
    bio = io.BytesIO()
    z = zipfile.ZipFile(bio, 'w', zipfile.ZIP_DEFLATED)
    n = len(sheets)
    z.writestr('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' + ''.join('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % (i + 1) for i in range(n)) + '</Types>')
    z.writestr('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
    names = []
    for i, (name, _) in enumerate(sheets):
        nm = re.sub(r'[\[\]\*\?/\\:]', ' ', str(name))[:31] or ('Sheet%d' % (i + 1))
        while nm in names: nm = nm[:28] + str(i)
        names.append(nm)
    z.writestr('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView/></bookViews><sheets>' + ''.join('<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (xesc(nm, {'"': '&quot;'}), i + 1, i + 1) for i, nm in enumerate(names)) + '</sheets></workbook>')
    z.writestr('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + ''.join('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>' % (i + 1, i + 1) for i in range(n)) + '<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' % (n + 1))
    z.writestr('xl/styles.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Arial"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Arial"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF0B5C8A"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="3" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>')
    for si, (_, rows) in enumerate(sheets):
        keys = []
        for r in rows:
            for k in r.keys():
                if k not in keys: keys.append(k)
        out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView rightToLeft="1" workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>']
        for ci, k in enumerate(keys):
            w = max([len(str(k))] + [len(str(r.get(k, '') or '')) for r in rows[:300]])
            out.append('<col min="%d" max="%d" width="%d" customWidth="1"/>' % (ci + 1, ci + 1, min(50, max(10, w + 2))))
        out.append('</cols><sheetData>')
        def cell(ref, v, style=0):
            st = ' s="%d"' % style if style else ''
            if v is None or v == '': return ''
            if isinstance(v, bool): v = 'نعم' if v else 'لا'
            if isinstance(v, (int, float)):
                return '<c r="%s"%s><v>%s</v></c>' % (ref, st or ' s="2"', repr(v) if isinstance(v, float) else v)
            s = str(v)
            s = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', s)
            return '<c r="%s" t="inlineStr"%s><is><t xml:space="preserve">%s</t></is></c>' % (ref, st, xesc(s))
        out.append('<row r="1">' + ''.join(cell(col_letter(i) + '1', k, 1) for i, k in enumerate(keys)) + '</row>')
        for ri, r in enumerate(rows):
            out.append('<row r="%d">' % (ri + 2) + ''.join(cell(col_letter(i) + str(ri + 2), r.get(k)) for i, k in enumerate(keys)) + '</row>')
        out.append('</sheetData>')
        if keys and rows: out.append('<autoFilter ref="A1:%s%d"/>' % (col_letter(len(keys) - 1), len(rows) + 1))
        out.append('</worksheet>')
        z.writestr('xl/worksheets/sheet%d.xml' % (si + 1), ''.join(out))
    z.close()
    return bio.getvalue()

NS = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
      'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
      'pr': 'http://schemas.openxmlformats.org/package/2006/relationships'}

def parse_xlsx(raw):
    z = zipfile.ZipFile(io.BytesIO(raw))
    shared = []
    if 'xl/sharedStrings.xml' in z.namelist():
        root = ET.fromstring(z.read('xl/sharedStrings.xml'))
        for si in root.findall('m:si', NS):
            shared.append(''.join(t.text or '' for t in si.iter('{%s}t' % NS['m'])))
    # date styles
    date_styles = set()
    if 'xl/styles.xml' in z.namelist():
        st = ET.fromstring(z.read('xl/styles.xml'))
        custom = {}
        nf = st.find('m:numFmts', NS)
        if nf is not None:
            for f in nf.findall('m:numFmt', NS):
                custom[int(f.get('numFmtId'))] = f.get('formatCode', '')
        xfs = st.find('m:cellXfs', NS)
        if xfs is not None:
            for i, xf in enumerate(xfs.findall('m:xf', NS)):
                fid = int(xf.get('numFmtId', 0))
                code = custom.get(fid, '')
                if 14 <= fid <= 22 or 45 <= fid <= 47 or (code and re.search(r'[dy]', code.lower()) and not re.search(r'[#0]', code)):
                    date_styles.add(i)
    wb = ET.fromstring(z.read('xl/workbook.xml'))
    rels = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
    relmap = {r.get('Id'): r.get('Target') for r in rels.findall('pr:Relationship', NS)}
    result = {}
    order = []
    for sh in wb.find('m:sheets', NS).findall('m:sheet', NS):
        name = sh.get('name'); rid = sh.get('{%s}id' % NS['r'])
        target = relmap.get(rid, '')
        path = target.lstrip('/') if target.startswith('/') else 'xl/' + target
        if path not in z.namelist(): continue
        root = ET.fromstring(z.read(path))
        grid = []
        for row in root.iter('{%s}row' % NS['m']):
            vals = {}
            for c in row.findall('m:c', NS):
                ref = c.get('r', ''); letters = re.match(r'[A-Z]+', ref)
                ci = 0
                if letters:
                    for ch in letters.group(0): ci = ci * 26 + (ord(ch) - 64)
                    ci -= 1
                t = c.get('t'); v = c.find('m:v', NS); s = int(c.get('s', 0))
                if t == 's' and v is not None: val = shared[int(v.text)]
                elif t == 'inlineStr':
                    val = ''.join(x.text or '' for x in c.iter('{%s}t' % NS['m']))
                elif t in ('str', 'e'): val = v.text if v is not None else ''
                elif t == 'b': val = (v.text == '1') if v is not None else ''
                elif v is not None and v.text is not None:
                    try:
                        num = float(v.text)
                        if s in date_styles:
                            d = datetime.datetime(1899, 12, 30) + datetime.timedelta(days=num)
                            val = d.strftime('%Y-%m-%d')
                        else:
                            val = int(num) if num.is_integer() else num
                    except ValueError:
                        val = v.text
                else: val = ''
                vals[ci] = val
            if vals:
                width = max(vals) + 1
                grid.append([vals.get(i, '') for i in range(width)])
        rows = []
        if grid:
            header = [str(h).strip() for h in grid[0]]
            for g in grid[1:]:
                if not any(str(x).strip() for x in g): continue
                rows.append({header[i]: (g[i] if i < len(g) else '') for i in range(len(header)) if header[i]})
        result[name] = rows; order.append(name)
    return {'sheetNames': order, 'sheets': result}

# ---------------- HTTP ----------------
MIME = {'.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
        '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
        '.woff2': 'font/woff2', '.pdf': 'application/pdf', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg'}

class H(BaseHTTPRequestHandler):
    server_version = 'ContractsSystem/1.0'

    def log_message(self, fmt, *args):
        if '/api/sync' in (args[0] if args else ''): return
        sys.stderr.write('%s  %s\n' % (now_iso(), fmt % args))

    # helpers
    def send_json(self, obj, code=200, headers=None):
        body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        for k, v in (headers or {}).items(): self.send_header(k, v)
        self.end_headers(); self.wfile.write(body)

    def send_bytes(self, data, mime, filename=None, cache=False):
        self.send_response(200)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'private, max-age=3600' if cache else 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        if filename:
            from urllib.parse import quote
            self.send_header('Content-Disposition', "attachment; filename*=UTF-8''%s" % quote(filename))
        self.end_headers(); self.wfile.write(data)

    def err(self, code, msg):
        self.send_json({'error': msg}, code)

    def body(self, limit=5 * 1024 * 1024):
        n = int(self.headers.get('Content-Length') or 0)
        if n > limit: raise ValueError('too_large')
        return self.rfile.read(n) if n else b''

    def jbody(self):
        b = self.body()
        return json.loads(b.decode('utf-8')) if b else {}

    def user(self):
        ck = cookies.SimpleCookie(self.headers.get('Cookie', ''))
        tok = ck.get('cs_session')
        if not tok: return None
        c = conn()
        r = c.execute('SELECT u.username,u.name,u.role,s.expires FROM sessions s JOIN users u ON u.username=s.username WHERE s.token=?', (tok.value,)).fetchone()
        c.close()
        if not r or r['expires'] < time.time(): return None
        return dict(r)

    def need(self, role=None):
        u = self.user()
        if not u: self.err(401, 'يلزم تسجيل الدخول'); return None
        rank = {'viewer': 0, 'editor': 1, 'admin': 2}
        if role and rank[u['role']] < rank[role]:
            self.err(403, 'لا تملك صلاحية تنفيذ هذا الإجراء'); return None
        return u

    def same_origin(self):
        """حماية من طلبات المواقع الأخرى (CSRF)."""
        origin = self.headers.get('Origin')
        if not origin: return True
        host = self.headers.get('Host', '')
        return urlparse(origin).netloc == host

    # routes
    def do_GET(self):
        p = urlparse(self.path); path = unquote(p.path); q = parse_qs(p.query)
        try:
            if path == '/api/me':
                u = self.user()
                return self.send_json(u if u else {'error': 'unauth'}, 200 if u else 401)
            if path == '/api/sync':
                u = self.need()
                if not u: return
                since = int(q.get('since', ['0'])[0] or 0)
                c = conn()
                mx = c.execute('SELECT COALESCE(MAX(ver),0) FROM docs').fetchone()[0]
                rows = c.execute('SELECT col,id,data,deleted,ver FROM docs WHERE ver>? ORDER BY ver', (since,)).fetchall()
                c.close()
                return self.send_json({'ver': mx, 'full': since == 0, 'docs': [
                    {'col': r['col'], 'id': r['id'], 'deleted': bool(r['deleted']), 'data': None if r['deleted'] else json.loads(r['data'])} for r in rows if not (since == 0 and r['deleted'])]})
            if path == '/api/users':
                u = self.need('admin')
                if not u: return
                c = conn(); rows = c.execute('SELECT username,name,role,created_at,last_login FROM users ORDER BY created_at').fetchall(); c.close()
                return self.send_json([dict(r) for r in rows])
            if path == '/api/log':
                u = self.need('admin')
                if not u: return
                lim = min(1000, int(q.get('limit', ['300'])[0]))
                c = conn(); rows = c.execute('SELECT * FROM log ORDER BY rowid DESC LIMIT ?', (lim,)).fetchall(); c.close()
                return self.send_json([dict(r) for r in rows])
            if path == '/api/backup':
                u = self.need('admin')
                if not u: return
                tmp = os.path.join(BACKUPS, '_download.db')
                src = conn(); dst = sqlite3.connect(tmp); src.backup(dst); dst.close(); src.close()
                data = open(tmp, 'rb').read(); os.remove(tmp)
                return self.send_bytes(data, 'application/octet-stream', 'نسخة-احتياطية-%s.db' % datetime.date.today().isoformat())
            if path.startswith('/files/'):
                u = self.need()
                if not u: return
                fid = path.split('/')[2]
                if not re.fullmatch(r'[A-Za-z0-9_-]+', fid): return self.err(404, 'غير موجود')
                c = conn(); r = c.execute('SELECT * FROM files WHERE id=?', (fid,)).fetchone(); c.close()
                fp = os.path.join(FILES, fid)
                if not r or not os.path.exists(fp): return self.err(404, 'الملف غير موجود')
                self.send_response(200)
                self.send_header('Content-Type', r['mime'] or 'application/octet-stream')
                from urllib.parse import quote
                self.send_header('Content-Disposition', "inline; filename*=UTF-8''%s" % quote(r['name'] or fid))
                self.send_header('Content-Length', str(os.path.getsize(fp)))
                self.send_header('X-Content-Type-Options', 'nosniff')
                self.end_headers()
                with open(fp, 'rb') as f: shutil.copyfileobj(f, self.wfile)
                return
            # static
            if path in ('', '/'): path = '/index.html'
            fp = os.path.normpath(os.path.join(STATIC, path.lstrip('/')))
            if not fp.startswith(STATIC) or not os.path.isfile(fp): return self.err(404, 'غير موجود')
            ext = os.path.splitext(fp)[1].lower()
            return self.send_bytes(open(fp, 'rb').read(), MIME.get(ext, 'application/octet-stream'), cache=ext in ('.woff2', '.png', '.svg'))
        except Exception as e:
            import traceback; traceback.print_exc()
            return self.err(500, 'خطأ في الخادم')

    def do_POST(self):
        p = urlparse(self.path); path = p.path; q = parse_qs(p.query)
        if not self.same_origin(): return self.err(403, 'طلب مرفوض')
        try:
            if path == '/api/login':
                b = self.jbody(); un = str(b.get('username', '')).strip().lower(); pw = str(b.get('password', ''))
                c = conn(); r = c.execute('SELECT * FROM users WHERE username=?', (un,)).fetchone()
                if not r or not hmac.compare_digest(hash_pw(pw, r['salt'])[0], r['pw_hash']):
                    c.close(); time.sleep(0.8)
                    return self.err(401, 'اسم المستخدم أو كلمة المرور غير صحيحة')
                tok = secrets.token_urlsafe(32)
                c.execute('DELETE FROM sessions WHERE expires<?', (time.time(),))
                c.execute('INSERT INTO sessions VALUES(?,?,?)', (tok, un, time.time() + SESSION_HOURS * 3600))
                c.execute('UPDATE users SET last_login=? WHERE username=?', (now_iso(), un))
                c.execute('INSERT INTO log VALUES(?,?,?,?,?,?)', (now_iso(), un, 'دخول', '', '', ''))
                c.commit(); c.close()
                return self.send_json({'username': un, 'name': r['name'], 'role': r['role']}, headers={'Set-Cookie': 'cs_session=%s; Path=/; HttpOnly; SameSite=Strict; Max-Age=%d' % (tok, SESSION_HOURS * 3600)})
            if path == '/api/logout':
                ck = cookies.SimpleCookie(self.headers.get('Cookie', '')); tok = ck.get('cs_session')
                if tok:
                    c = conn(); c.execute('DELETE FROM sessions WHERE token=?', (tok.value,)); c.commit(); c.close()
                return self.send_json({'ok': True}, headers={'Set-Cookie': 'cs_session=; Path=/; Max-Age=0'})
            if path == '/api/password':
                u = self.need()
                if not u: return
                b = self.jbody(); old = b.get('old', ''); new = b.get('new', '')
                if len(new) < 8: return self.err(400, 'كلمة المرور الجديدة يجب ألا تقل عن 8 أحرف')
                c = conn(); r = c.execute('SELECT * FROM users WHERE username=?', (u['username'],)).fetchone()
                if not hmac.compare_digest(hash_pw(old, r['salt'])[0], r['pw_hash']):
                    c.close(); return self.err(400, 'كلمة المرور الحالية غير صحيحة')
                h, s = hash_pw(new)
                c.execute('UPDATE users SET pw_hash=?, salt=? WHERE username=?', (h, s, u['username']))
                c.execute('INSERT INTO log VALUES(?,?,?,?,?,?)', (now_iso(), u['username'], 'تغيير كلمة المرور', '', '', ''))
                c.commit(); c.close()
                return self.send_json({'ok': True})
            if path == '/api/users':
                u = self.need('admin')
                if not u: return
                b = self.jbody(); un = str(b.get('username', '')).strip().lower()
                if not re.fullmatch(r'[a-z0-9._-]{3,32}', un): return self.err(400, 'اسم المستخدم: 3 أحرف إنجليزية أو أرقام على الأقل، بدون مسافات')
                role = b.get('role', 'viewer')
                if role not in ROLES: return self.err(400, 'صلاحية غير معروفة')
                name = str(b.get('name', '')).strip() or un
                pw = b.get('password') or ''
                c = conn(); ex = c.execute('SELECT * FROM users WHERE username=?', (un,)).fetchone()
                if ex:
                    if ex['role'] == 'admin' and role != 'admin' and c.execute("SELECT COUNT(*) FROM users WHERE role='admin'").fetchone()[0] <= 1:
                        c.close(); return self.err(400, 'لا يمكن إزالة صلاحية آخر مدير للنظام')
                    c.execute('UPDATE users SET name=?, role=? WHERE username=?', (name, role, un))
                    if pw:
                        if len(pw) < 8: c.close(); return self.err(400, 'كلمة المرور يجب ألا تقل عن 8 أحرف')
                        h, s = hash_pw(pw); c.execute('UPDATE users SET pw_hash=?, salt=? WHERE username=?', (h, s, un))
                        c.execute('DELETE FROM sessions WHERE username=?', (un,))
                    act = 'تعديل مستخدم'
                else:
                    if len(pw) < 8: c.close(); return self.err(400, 'كلمة المرور يجب ألا تقل عن 8 أحرف')
                    h, s = hash_pw(pw)
                    c.execute('INSERT INTO users VALUES(?,?,?,?,?,?,NULL)', (un, name, role, h, s, now_iso()))
                    act = 'إضافة مستخدم'
                c.execute('INSERT INTO log VALUES(?,?,?,?,?,?)', (now_iso(), u['username'], act, 'users', un, '%s (%s)' % (name, ROLES[role])))
                c.commit(); c.close()
                return self.send_json({'ok': True})
            if path == '/api/upload':
                u = self.need('editor')
                if not u: return
                raw = self.body(MAX_UPLOAD)
                name = unquote(q.get('name', ['file'])[0])[:200]
                mime = self.headers.get('Content-Type', 'application/octet-stream')
                if mime not in ('application/pdf', 'image/png', 'image/jpeg'): return self.err(400, 'يُقبل ملف PDF أو صورة فقط')
                fid = secrets.token_urlsafe(12)
                with open(os.path.join(FILES, fid), 'wb') as f: f.write(raw)
                c = conn(); c.execute('INSERT INTO files VALUES(?,?,?,?,?,?)', (fid, name, mime, len(raw), u['username'], now_iso()))
                c.execute('INSERT INTO log VALUES(?,?,?,?,?,?)', (now_iso(), u['username'], 'رفع ملف', 'files', fid, name)); c.commit(); c.close()
                return self.send_json({'id': fid, 'url': '/files/' + fid, 'sizeBytes': len(raw), 'contentType': mime})
            if path == '/api/xlsx':
                u = self.need()
                if not u: return
                b = json.loads(self.body(60 * 1024 * 1024).decode('utf-8'))
                data = build_xlsx(b.get('sheets', []))
                return self.send_bytes(data, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', b.get('filename') or 'export.xlsx')
            if path == '/api/xlsx/parse':
                u = self.need('editor')
                if not u: return
                raw = self.body(30 * 1024 * 1024)
                try: return self.send_json(parse_xlsx(raw))
                except Exception as e: return self.err(400, 'تعذّرت قراءة الملف. تأكد أنه ملف Excel بصيغة xlsx.')
            return self.err(404, 'غير موجود')
        except ValueError as e:
            return self.err(413 if str(e) == 'too_large' else 400, 'الطلب غير صالح أو كبير جدًا')
        except Exception:
            import traceback; traceback.print_exc()
            return self.err(500, 'خطأ في الخادم')

    def do_PUT(self):
        if not self.same_origin(): return self.err(403, 'طلب مرفوض')
        m = re.fullmatch(r'/api/doc/([a-z]+)/([A-Za-z0-9_\-.~:@+]{1,200})', urlparse(self.path).path)
        if not m: return self.err(404, 'غير موجود')
        u = self.need('editor')
        if not u: return
        col, did = m.groups()
        if col not in COLLECTIONS: return self.err(400, 'مجموعة غير معروفة')
        try: data = self.jbody()
        except Exception: return self.err(400, 'بيانات غير صالحة')
        if not isinstance(data, dict): return self.err(400, 'بيانات غير صالحة')
        with LOCK:
            c = conn()
            ver = c.execute('SELECT COALESCE(MAX(ver),0) FROM docs').fetchone()[0] + 1
            existed = c.execute('SELECT deleted FROM docs WHERE col=? AND id=?', (col, did)).fetchone()
            c.execute('INSERT OR REPLACE INTO docs VALUES(?,?,?,?,0,?,?)', (col, did, json.dumps(data, ensure_ascii=False), ver, now_iso(), u['username']))
            act = 'تعديل' if existed and not existed['deleted'] else 'إضافة'
            c.execute('INSERT INTO log VALUES(?,?,?,?,?,?)', (now_iso(), u['username'], act, col, did, summarize(col, data)))
            c.commit(); c.close()
        return self.send_json({'ok': True, 'ver': ver})

    def do_DELETE(self):
        if not self.same_origin(): return self.err(403, 'طلب مرفوض')
        path = urlparse(self.path).path
        m = re.fullmatch(r'/api/users/([a-z0-9._-]+)', path)
        if m:
            u = self.need('admin')
            if not u: return
            un = m.group(1)
            if un == u['username']: return self.err(400, 'لا يمكنك حذف حسابك')
            c = conn(); c.execute('DELETE FROM users WHERE username=?', (un,)); c.execute('DELETE FROM sessions WHERE username=?', (un,))
            c.execute('INSERT INTO log VALUES(?,?,?,?,?,?)', (now_iso(), u['username'], 'حذف مستخدم', 'users', un, '')); c.commit(); c.close()
            return self.send_json({'ok': True})
        m = re.fullmatch(r'/api/doc/([a-z]+)/([A-Za-z0-9_\-.~:@+]{1,200})', path)
        if not m: return self.err(404, 'غير موجود')
        u = self.need('editor')
        if not u: return
        col, did = m.groups()
        with LOCK:
            c = conn()
            r = c.execute('SELECT data FROM docs WHERE col=? AND id=?', (col, did)).fetchone()
            ver = c.execute('SELECT COALESCE(MAX(ver),0) FROM docs').fetchone()[0] + 1
            c.execute('UPDATE docs SET deleted=1, ver=?, updated_at=?, updated_by=? WHERE col=? AND id=?', (ver, now_iso(), u['username'], col, did))
            c.execute('INSERT INTO log VALUES(?,?,?,?,?,?)', (now_iso(), u['username'], 'حذف', col, did, summarize(col, json.loads(r['data'])) if r else ''))
            c.commit(); c.close()
        return self.send_json({'ok': True})

def main():
    ap = argparse.ArgumentParser(description='منظومة العقود والاحتياجات')
    ap.add_argument('--port', type=int, default=int(os.environ.get('PORT', 8080)))
    ap.add_argument('--host', default=os.environ.get('HOST', '0.0.0.0'))
    ap.add_argument('--reset-admin', action='store_true', help='إعادة تعيين كلمة مرور المستخدم admin')
    a = ap.parse_args()
    init_db()
    if a.reset_admin:
        pw = secrets.token_urlsafe(9); h, s = hash_pw(pw)
        c = conn()
        if c.execute("SELECT 1 FROM users WHERE username='admin'").fetchone():
            c.execute("UPDATE users SET pw_hash=?, salt=?, role='admin' WHERE username='admin'", (h, s))
        else:
            c.execute('INSERT INTO users VALUES(?,?,?,?,?,?,NULL)', ('admin', 'مدير النظام', 'admin', h, s, now_iso()))
        c.execute("DELETE FROM sessions WHERE username='admin'"); c.commit(); c.close()
        print('كلمة المرور الجديدة للمستخدم admin:  %s' % pw); return
    threading.Thread(target=daily_backup, daemon=True).start()
    srv = ThreadingHTTPServer((a.host, a.port), H)
    import socket
    ip = 'عنوان-الخادم'
    try:
        sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); sk.connect(('10.255.255.255', 1)); ip = sk.getsockname()[0]; sk.close()
    except Exception:
        try: ip = socket.gethostbyname(socket.gethostname())
        except Exception: pass
    print('  المنظومة تعمل الآن. افتحها من أي جهاز في الشبكة على:')
    print('     http://%s:%d' % (ip, a.port))
    print('     http://localhost:%d   (من نفس الخادم)' % a.port)
    print('  للإيقاف: Ctrl+C\n')
    try: srv.serve_forever()
    except KeyboardInterrupt: print('\nتم الإيقاف.')

if __name__ == '__main__':
    if hasattr(sys.stdout, 'reconfigure'):
        try: sys.stdout.reconfigure(encoding='utf-8')
        except Exception: pass
    main()
